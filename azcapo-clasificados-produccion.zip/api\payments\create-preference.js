const { sql } = require('../../lib/db');
const { authMiddleware } = require('../../lib/auth');
const { createPreference } = require('../../lib/mercadopago');
const { cors } = require('../../lib/cors');

const PREMIUM_PRICE = 56.23;

module.exports = async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const user = authMiddleware(req);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Debes iniciar sesión.' });
    }

    const { adPublicId, title } = req.body || {};
    if (!adPublicId) {
      return res.status(400).json({ success: false, message: 'Se requiere el ID del anuncio.' });
    }

    // Verify ad exists and belongs to user
    const ads = await sql`SELECT * FROM ads WHERE public_id = ${adPublicId} AND owner_id = ${user.userId}`;
    if (ads.length === 0) {
      return res.status(404).json({ success: false, message: 'Anuncio no encontrado.' });
    }

    // Build notification URL (webhook)
    const protocol = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const baseUrl = `${protocol}://${host}`;

    const preference = await createPreference({
      title: title || ads[0].title,
      amount: PREMIUM_PRICE,
      externalReference: adPublicId,
      notificationUrl: `${baseUrl}/api/payments/webhook`,
      backUrl: baseUrl,
    });

    // Record pending payment
    await sql`
      INSERT INTO payments (ad_public_id, mp_preference_id, status, amount)
      VALUES (${adPublicId}, ${preference.id}, 'pending', ${PREMIUM_PRICE})
    `;

    return res.status(200).json({
      success: true,
      preferenceId: preference.id,
      initPoint: preference.init_point,
      sandboxInitPoint: preference.sandbox_init_point,
    });
  } catch (error) {
    console.error('Create preference error:', error);
    return res.status(500).json({ success: false, message: 'Error al crear preferencia de pago.' });
  }
};
